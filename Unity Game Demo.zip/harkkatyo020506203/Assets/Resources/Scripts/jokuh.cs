﻿using UnityEngine;
using System.Collections;

public class jokuh : MonoBehaviour {
	private bool ballIsActive;
	private Vector3 ballPosition;
	private Vector3 originalplace;
	private Vector2 ballInitialForce;
	// Use this for initialization
	public static float timem2;
	// GameObject
	public GameObject playerObject;
	public GameObject ballObject;
	public ParticleSystem ps2;
	public Object particleSystems;
	private bool active;

	void Start() {
		gameObject.SetActive (true);
		// create the force
		ballInitialForce = new Vector2 (100.0f,800.0f);

		// set to inactive
		ballIsActive = false;

		// ball position
		ballPosition = transform.position;

		//original place of ball
		originalplace.y = transform.position.y;
	}
	void OnTriggerEnter(Collider col) {
		if(active) {
			gameObject.SetActive (true);


		}
	}
		

		void Awake() {
			Start ();
			particleSystems = Resources.Load ("Explosions/Flame", typeof(GameObject));
		}
		//public Texture btnTexture;

		// Update is called once per frame
		void Update () {
		if(Input.GetKey(KeyCode.Q)) {
			//Debug.Log ("ulostuloa");
			gameObject.GetComponent<Renderer>().enabled = false;
			gameObject.GetComponent<CircleCollider2D> ().enabled = false;
			//gameObject.GetComponent<Renderer> ().enabled = true;
		}
		if(Input.GetKeyDown(KeyCode.G)) {
			gameObject.GetComponent<Renderer>().enabled = true;
			gameObject.GetComponent<CircleCollider2D> ().enabled = true;
		}
			timem2 += Time.deltaTime;

			// check for user input
			if (Input.GetButtonDown ("Jump") == true) {
				// check if is the first play
				if (!ballIsActive){
					// reset the force
					GetComponent<Rigidbody2D>().isKinematic = false;

					// add a force
					GetComponent<Rigidbody2D>().AddForce(ballInitialForce);

					// set ball active
					ballIsActive = !ballIsActive;
				}
			}
			if (Input.GetKeyDown (KeyCode.H)) {
				//ballPosition = transform.position;
				ballIsActive = !ballIsActive;
				//ballPosition.x = playerObject.transform.position.x;
				ballPosition.y = originalplace.y;//playerObject.transform.position.y;

				//ballPosition.y = ballPosition.y - 20;
				//ballPosition.y = -4.2f;
				//transform.position = ballPosition;

				GetComponent<Rigidbody2D>().isKinematic = true;
			}

			if (!ballIsActive && playerObject != null){

				// get and use the player position
				ballPosition.x = playerObject.transform.position.x;

				// apply player X position to the ball
				transform.position = ballPosition;
			}


			// Check if ball falls
			if (ballIsActive && transform.position.y < -15.2f) {
				ballIsActive = !ballIsActive;
				ballPosition.x = playerObject.transform.position.x;
				ballPosition.y = originalplace.y; //-4.2f too
				transform.position = ballPosition;

				GetComponent<Rigidbody2D>().isKinematic = true;

				playerObject.SendMessage("TakeLife");
			}

		}
		void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "ballm") {


			//
			//Debug.Log ("lisääsli0923493242");
			//GameObject go4;
			//prefabEffect.transform.SetParent (fpcontoler);
			//string m0;
			//m0 = gameObject.transform.GetChild (0).name;
			//hand = GameObject.Find("Player/Explosionx/Flame");
			//hand.SetActive (true);
			ps2.Play ();

		}


			if (collision.gameObject.tag == "bottomplace") {
				//DestroyObject (ballObject);
				//Debug.Log("je");
				ballIsActive = !ballIsActive;
				ballPosition.y = originalplace.y;
				//ballPosition = transform.position;
				GetComponent<Rigidbody2D>().isKinematic = true;
			}
		}

	}

