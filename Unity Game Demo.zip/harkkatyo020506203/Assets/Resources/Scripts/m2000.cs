﻿using UnityEngine;
using System.Collections;

public class m2000 : MonoBehaviour {
		
		//public Collider boxCol;
		//public Collider boxCol2;

		public Transform Prefab;

		public Transform Prefab200;

		//public GameObject m20000;
		//public GameObject muuttuja22;

	// Use this for initialization
	void Start () {
	Physics.IgnoreLayerCollision(1, 4);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
		void OnCollisionEnter2D(Collision2D collision){

				if (collision.gameObject.tag == "Ball") {
						//boxCol = GameObject.Find ("Ball").GetComponent<Collider>();
						//boxCol2 = GameObject.Find ("BarTop2").GetComponent<Collider>();
						//m20000 = GameObject.Find("BarTop2");
						//muuttuja22 = GameObject.Find("Ball");
						//Physics.IgnoreCollision (boxCol, boxCol2);

						//Transform mullet02 = Instantiate(Prefab) as Transform;

						//Transform keijollaonjoo2 = Instantiate(Prefab200) as Transform;

						//Physics.IgnoreCollision(mullet02.GetComponent<Collider>(), keijollaonjoo2.GetComponent<Collider>());


						//GameObject ps = particleSystem.name;
						//GameObject go = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
						//Destroy (go, 10);

						//collision.enabled = false;

				}
						
		}
}
