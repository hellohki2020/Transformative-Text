﻿using UnityEngine;
using System.Collections;

public class shakerrr : MonoBehaviour {
	float speed = 1.0f; //how fast it shakes
	float amount = 1.0f; //how much it shakes
	// Use this for initialization
	public float mass;
	public Rigidbody2D rb;
	private bool ballIsActive;
	public GameObject playerObject;
	private Vector3 ballPosition;
	private Vector3 originalplace;
	public GameObject respawn;
	int mass2 = 0;
	void Start () {
		
		mass2 = Random.Range(0, 8);
		rb = GetComponent<Rigidbody2D>();

		rb.mass = mass2;
		//Debug.Log ("painoa " + mass2);
		// set to inactive
		ballIsActive = false;

		// ball position
		ballPosition = transform.position;

		//original place of ball
		originalplace.y = transform.position.y;
	}
	
	// Update is called once per frame
	bool Up;
	float timer;

	void Update(){
		timer += Time.deltaTime;
		if (timer <= 10) {
			if (Up) {
				transform.Translate (0, 2f, 0);
				Up = false;
			} else {
				transform.Translate (0, -2f, 0);
				Up = true;
			}

		} else {
			respawn = GameObject.FindWithTag ("ta2");
			Destroy (respawn);
			//Destroy (this.gameObject);
		}
		//Debug.Log ("mo mo mo " + transform.position.y);
		// Check if ball falls
		if (transform.position.y < -4) {
			Destroy (this.gameObject);
			//ballIsActive = !ballIsActive;
			//ballPosition.x = playerObject.transform.position.x;
			//ballPosition.y = -4.2f; //-4.2f too
			//transform.position = ballPosition;

			//GetComponent<Rigidbody2D>().isKinematic = true;

			//playerObject.SendMessage("TakeLife");
		}
	}
}
