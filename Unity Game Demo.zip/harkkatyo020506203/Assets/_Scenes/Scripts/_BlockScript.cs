﻿using UnityEngine;
using System.Collections;

public class _BlockScript : MonoBehaviour {

	public int hitsToKill;
	public int points;
	private int numberOfHits;
	private Vector2 liikettaobjektia;
	private Transform target;
	private float speed = 2f;
	private Vector3 speedRot = Vector3.right * 50f;
	public float delta = 5.5f;  // Amount to move left and right from the start point
	private Vector3 startPos;
	// Use this for initialization
	
	// Update is called once per frame

	void Start () {
				numberOfHits = 0;
				PlayerPrefs.SetInt ("Score", 0);
				//liikettaobjektia = new Vector2 (20.0f,0.0f);
		target = GameObject.FindGameObjectWithTag("Player").transform;

		startPos = transform.position;
	}

	void Update ()
	{
		//move towards player...
		if (GameObject.Find ("Player") != null) {
			transform.Rotate (speedRot * Time.deltaTime);
			transform.position = Vector3.MoveTowards (transform.position, target.position, speed * Time.deltaTime);

			Vector3 v = startPos;
			v.x += delta * Mathf.Sin (Time.time * speed);
			transform.position = v;
		} else {
			//Destroy (this.gameObject, 2);
		}
	}

	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "Ball"){
			numberOfHits++;

			if (numberOfHits == hitsToKill){

				// get reference of player object
				//GameObject player = GameObject.FindGameObjectsWithTag("Player")[0];

				// send message
				//player.SendMessage("addPoints", points);
				PlayerPrefs.SetInt("Score", PlayerPrefs.GetInt("Score")+10);
				

				// destroy the object
				Destroy(this.gameObject);
			}
		}
				/*if (collision.gameObject.tag == "Baroikea") {
						liikettaobjektia = new Vector2 (-27.0f,2.0f);
						//print ("moro");
				}
				if (collision.gameObject.tag == "Barvasen") {
						liikettaobjektia = new Vector2 (20.0f,0.0f);
				}*/
	}

}
