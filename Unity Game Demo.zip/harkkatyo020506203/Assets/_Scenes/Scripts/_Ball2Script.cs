using UnityEngine;
using System.Collections;

public class _Ball2Script : MonoBehaviour {

		private Transform target;
		private float speed = 10f;
		private Vector3 speedRot = Vector3.right * 50f;
		private Vector3 ballPosition;
		private Vector3 originalplace;
		private bool ballIsActive;
	private Vector2 ballInitialForce;

	float x;
	float y;
	float z;
	Vector3 pos;
	// GameObject
	public GameObject playerObject;
	public GameObject ballObject;
	public static float timem2;

	//net
	float delay = 0.5f;
	float threshold = 0.1f;

		void Start () {
		ballInitialForce = new Vector2 (10.0f,10.0f);

		// set to inactive
		ballIsActive = false;

		// ball position
		ballPosition = transform.position;
			target = GameObject.FindGameObjectWithTag("Player").transform;
		GetComponent<Rigidbody2D>().isKinematic = false;
		//original place of ball
		x = Random.Range(-25, 26);
		y = 5;
		z = Random.Range(-25, 26);
		pos = new Vector3(x, y, z);
			originalplace.y = transform.position.y;
		} 

		void Update () {
		if (GameObject.Find ("Player") != null) {
		} else {
			//Destroy (this.gameObject, 2);
		}
		//transform.position = pos;
			transform.Rotate (speedRot * Time.deltaTime);
		//Vector3 temp = transform.position;
		//temp.x = -200;
		//temp.y = 0;
		//temp.z = 0;
		//Vector3 test2 = playerObject.transform.position; 
		//Random.onUnitSphere * Random.Range(0, 202)
		if (transform.position.y < -3) {
			//Destroy (this.gameObject, 0.1f);
		}
		if (GameObject.Find ("Player") != null) {
			transform.position = Vector3.MoveTowards (transform.position, target.position, Random.Range (speed, 20f) * Time.deltaTime);
		}

		//if (GetComponent<Rigidbody2D>().velocity.magnitude < 0.01) {
			//StartCoroutine("LoadTheLevel");
		//}
		//if(GetComponent<Rigidbody2D> ().angularVelocity < .01)//much faster than magnitude
			//Destroy (this.gameObject);		
			//StartCoroutine("LoadTheLevel");

	}

	/*IEnumerator LoadTheLevel()
	{
		float elapsed = 0f;

		while (GetComponent<Rigidbody2D>().velocity.magnitude < threshold * threshold)
		{
			
			elapsed += Time.deltaTime;
			Debug.Log ("elapsed: " + elapsed);
			if(elapsed >= delay)
			{
				Destroy (this.gameObject);
				//Application.LoadLevel(2);
				yield break;
			}
			yield return null;
		}
		yield break;
	}*/
			
		
	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "onthetop") {
			//DestroyObject (ballObject);
			//Debug.Log("jj");
			x = Random.Range(-25, 26);
			y = 5;
			z = Random.Range(-25, 26);
			pos = new Vector3(x, y, z);
			//Start ();
			//originalplace.y = transform.position.y;
			Vector3 temp = transform.position;
			//if (GameObject.Find ("Player") != null) {
			//	if(this.gameObject != null) 
			//string name = playerObject.ToString();
			//if(GameObject.Find(name) != null)
				temp.x = playerObject.transform.position.x;

				temp.y = originalplace.y;
				transform.position = temp;
				//Debug.Log("y0" + playerObject.transform.position.y);
				//Debug.Log ("jj" + originalplace.y);
				//Debug.Log ("jj3" + ballPosition.y);
			//}

			//transform.position.y = originalplace.y;
			//Destroy (this.gameObject);
			//ballIsActive = !ballIsActive;
			//ballPosition.y = originalplace.y;


			//ballPosition = transform.position;
			//GetComponent<Rigidbody2D>().isKinematic = true;
		}
	}

	}
