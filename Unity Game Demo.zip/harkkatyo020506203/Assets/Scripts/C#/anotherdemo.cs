﻿using UnityEngine;
using System.Collections;

public class anotherdemo : MonoBehaviour {

	// Use this for initialization
	void Start () {
		var instance = new DemoScript ();

		//shouldText = true;
		//currentMode = Mode.text;
		//text päälle
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
